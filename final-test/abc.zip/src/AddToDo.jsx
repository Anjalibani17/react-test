import React, { useState } from 'react';
import { useDispatch } from "react-redux";
import { addTodo } from "./todoSlider";

const AddToDo = () => {
	const [value, setValue] = useState('');
	const dispatch = useDispatch();

	const onSubmit = (event) => {
		event.preventDefault();
		if (value) {
			setValue("")
			dispatch(
				addTodo({
					title: value,
				})
			);
		}
	};

	return (
		<form onSubmit={onSubmit} >
			<input
				type='text'
				
				placeholder='Add a todo name'
				value={value}
				onChange={(event) => setValue(event.target.value)}>

			</input>

			<button type='submit' >
				Add task
			</button>
		</form>
	);
};

export default AddToDo;
