import React, { useState } from 'react';

const AddUser = ({ onUsernameSubmit }) => {
  const [inputValue, setInputValue] = useState('');
  const [displayValue, setDisplayValue] = useState([]);

  const handleChange = (event) => {
    setInputValue(event.target.value);
  };

  const handleSubmit = () => {
    setDisplayValue([...displayValue, inputValue]);
    onUsernameSubmit(inputValue);
    setInputValue('');
  };

  return (
    <>
      <input
        type="text"
        value={inputValue}
        onChange={handleChange}
        placeholder="Enter user here"
      />
      <button onClick={handleSubmit}>Add User</button>
      <div>
        <h2>User List:</h2>
        <ul>
          {displayValue.map((value, index) => (
            <li key={index}>{value}</li>
          ))}
        </ul>
      </div>
    </>
  );
};

export default AddUser;
