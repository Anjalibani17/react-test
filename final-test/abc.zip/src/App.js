import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import ToDoListView from './ToDoListView';
import AddUser from './AddUser';
import Users from './Users';
import AddToDo from './AddToDo';
import { useState } from 'react';


const App = () => {
  const [username, setUsername] = useState('');
  const handleUsernameChange = (event) => {
    setUsername(event.target.value);
  };
  
  return (
    <Router>
      <div>
        
        <nav>
          <ul>
            <li>
              <Link to="/todolist">Todo List</Link>
            </li>
            <li>
              <Link to="/users">Users</Link>
            </li>
            <li>
              <Link to="/addusers">Add Users</Link>
            </li>
          </ul>
        </nav>

        <Routes>
          <Route path="/todolist" element={<>
        
            <AddToDo />
      <ToDoListView />  
         
      </> } />
          <Route path="/users" element={<Users username={username}/>} />
          <Route path="/addusers" element={<AddUser onUsernameSubmit={handleUsernameChange} />} />

        </Routes>
      </div>
    </Router>
  );
};

export default App;
