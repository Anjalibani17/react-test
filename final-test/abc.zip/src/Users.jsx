import { useState,useEffect } from "react"
const Users = ({username}) => {
    const [users, setUsers] = useState([])

    

    const fetchUserData = () => {
        fetch("https://jsonplaceholder.typicode.com/users")
            .then(response => {
                return response.json()
            })
            .then(data => {
                setUsers(data)
            })
    }

    useEffect(() => {
        fetchUserData()
    }, [])

    return (
        <div>
            <h2>users list </h2>
            {users.length > 0 && (
                <ol>
                    {users.map(user => (
                        <li key={user.id}>{user.name}{username}</li>
                    ))}
                </ol>
            )}
        </div>
    );
}
export default Users;